"""Alert evaluation and logging (everything here is simulated)."""
import time
from datetime import datetime
import streamlit as st
import database as db
from config import check, ORDER

COOLDOWN_SECONDS = 60  # don't re-log the same alert every refresh


def evaluate(reading, thresholds):
    """Return the alerts that are active for the current reading."""
    active = []
    for key, th in thresholds.items():
        level, direction = check(reading[key], th)
        if level == "normal":
            continue
        active.append(dict(
            key=key, severity=level,
            type="Vital Sign" if th["kind"] == "vital" else "Environment",
            message=f"{th['label']} {direction}: {reading[key]} {th['unit']} "
                    f"(normal {th['low']}–{th['high']})"))
    return sorted(active, key=lambda a: -ORDER[a["severity"]])


def log(alert_type, severity, message):
    ss = st.session_state
    db.add_alert(datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                 ss.patient["patient_id"], alert_type, severity, message)


def record_active(active):
    """Save active alerts to history, at most once per cooldown period."""
    ss = st.session_state
    now = time.time()
    for a in active:
        key = (ss.patient["patient_id"], a["key"], a["severity"])
        if now - ss.alert_last.get(key, 0) >= COOLDOWN_SECONDS:
            ss.alert_last[key] = now
            log(a["type"], a["severity"], a["message"])
