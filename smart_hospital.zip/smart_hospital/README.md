# Smart Hospital Room Monitoring System

Beginner-friendly Streamlit dashboard using **simulated** sensors (no real hardware,
SMS, or EHR connection).

## Run
    pip install -r requirements.txt
    streamlit run app.py

## Structure
    app.py            sidebar, navigation, auto-refresh
    core.py           session state, new-reading "tick", auto climate control
    simulator.py      random-walk sensor simulation + demo scenarios
    config.py         default thresholds and normal/warning/critical check
    alerts.py         alert detection + logging
    database.py       SQLite (patients, alert history) -> data/hospital.db
    ui.py             metric cards, Plotly charts, buttons
    views/            dashboard, ehr, environment, alerts_page, settings_page

## Try it
Settings -> Scenario -> "Hot & dry room": watch Auto Mode switch on the fan, AC and humidifier.
"Fever & fast heart rate" / "Low oxygen" trigger vital-sign alerts.
Requires Streamlit 1.37+ (uses st.fragment for live refresh).
