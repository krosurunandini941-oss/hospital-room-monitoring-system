from datetime import date
import streamlit as st
import database as db

LIVE = False


def render():
    ss, p = st.session_state, st.session_state.patient
    st.title("🧑‍⚕️ Patient / EHR (Simulated)")
    if ss.get("flash"):
        st.success(ss.pop("flash"))
    st.caption("Local demo database only – not connected to any real hospital system. "
               "Enter a new Patient ID to add a new patient.")

    with st.form("ehr_form"):
        c1, c2 = st.columns(2)
        pid = c1.text_input("Patient ID", value=p["patient_id"])
        name = c2.text_input("Patient Name", value=p["name"])
        age = c1.number_input("Age", 0, 120, int(p["age"]))
        room = c2.text_input("Room Number", value=p["room"])
        doctor = c1.text_input("Doctor Name", value=p["doctor"])
        admitted = c2.date_input("Admission Date", value=date.fromisoformat(p["admission_date"]))
        if st.form_submit_button("💾 Save Patient Data", type="primary"):
            if not pid.strip() or not name.strip():
                st.error("Patient ID and Name are required.")
            else:
                db.save_patient(pid.strip(), name.strip(), int(age), room.strip(),
                                doctor.strip(), admitted.isoformat())
                ss.flash = f"Saved patient {name.strip()} ({pid.strip()}) to the local database."
                st.rerun()

    st.subheader("All patients")
    st.dataframe(db.get_patients(), use_container_width=True, hide_index=True)
