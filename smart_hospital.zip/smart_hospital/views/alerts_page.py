import pandas as pd
import streamlit as st
import alerts, core, database as db, ui

LIVE = True


def render():
    ss = st.session_state
    cur = core.history_df().iloc[-1]
    st.title("🔔 Alerts")

    st.subheader("Active alerts")
    ui.show_alerts(alerts.evaluate(cur, ss.thresholds))
    ui.call_buttons("alerts", cur)

    st.subheader("Alert history")
    rows = db.get_alerts()
    if not rows:
        st.info("No alerts recorded yet.")
        return
    df = pd.DataFrame(rows)
    df.columns = ["Timestamp", "Patient", "Type", "Severity", "Message"]
    c = st.columns(3)
    c[0].metric("Total alerts", len(df))
    c[1].metric("Critical", int((df["Severity"] == "critical").sum()))
    c[2].metric("Nurse calls", int((df["Type"] == "Nurse Call").sum()))
    types = st.multiselect("Filter by type", sorted(df["Type"].unique()),
                           default=sorted(df["Type"].unique()), key="alert_filter")
    st.dataframe(df[df["Type"].isin(types)], use_container_width=True, hide_index=True)
    if st.button("🗑️ Clear alert history", key="clear_alerts"):
        db.clear_alerts()
        ss.alert_last = {}
        st.rerun()
