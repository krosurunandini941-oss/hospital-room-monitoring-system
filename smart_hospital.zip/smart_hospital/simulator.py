"""Simulated sensors: a mean-reverting random walk so charts look continuous."""
import numpy as np

# name: (typical value, step noise, min, max, pull-back strength)
PARAMS = {
    "heart_rate":  (78, 1.5, 40, 180, 0.08),
    "systolic":    (115, 1.8, 70, 200, 0.08),
    "diastolic":   (75, 1.2, 40, 120, 0.08),
    "spo2":        (97.5, 0.3, 70, 100, 0.10),
    "resp_rate":   (16, 0.5, 6, 40, 0.10),
    "temperature": (36.9, 0.05, 34, 41, 0.05),
    "room_temp":   (24.5, 0.15, 15, 35, 0.05),
    "humidity":    (50, 0.6, 20, 90, 0.05),
    "air_quality": (45, 3, 0, 300, 0.08),
    "co":          (2, 0.3, 0, 60, 0.10),
    "co2":         (650, 25, 350, 3000, 0.08),
}
DECIMALS = {"heart_rate": 0, "systolic": 0, "diastolic": 0, "spo2": 1, "resp_rate": 1,
            "temperature": 2, "room_temp": 1, "humidity": 1, "air_quality": 0, "co": 1, "co2": 0}

# "What if" cases for demos: they shift the value the readings drift toward.
SCENARIOS = {
    "Normal": {},
    "Fever & fast heart rate": {"temperature": 38.8, "heart_rate": 112, "resp_rate": 22},
    "Low oxygen": {"spo2": 91, "resp_rate": 24, "heart_rate": 105},
    "Hot & dry room": {"room_temp": 30, "humidity": 32},
    "Poor air quality": {"air_quality": 160, "co": 15, "co2": 1600},
}


class SensorSimulator:
    def __init__(self, seed=None):
        self.rng = np.random.default_rng(seed)
        self.values = {k: float(p[0]) for k, p in PARAMS.items()}
        self.scenario = {}

    def set_scenario(self, name):
        self.scenario = SCENARIOS.get(name, {})

    def step(self, devices=None):
        """Produce the next reading. Running devices pull the room toward comfort."""
        devices = devices or {}
        offset = {"room_temp": 0.0, "humidity": 0.0}
        if devices.get("ac"):
            offset["room_temp"] -= 3.5
        if devices.get("fan"):
            offset["room_temp"] -= 1.0
        if devices.get("humidifier"):
            offset["humidity"] += 14.0

        for name, (mean, std, lo, hi, pull) in PARAMS.items():
            target = self.scenario.get(name, mean) + offset.get(name, 0.0)
            if offset.get(name):
                pull = max(pull, 0.12)  # devices act faster
            v = self.values[name]
            v += pull * (target - v) + self.rng.normal(0, std)
            self.values[name] = float(np.clip(v, lo, hi))

        return {k: round(v, DECIMALS[k]) for k, v in self.values.items()}
