"""Reusable UI pieces."""
import plotly.graph_objects as go
import streamlit as st
import alerts
import core

ICON = {"normal": "✅ Normal", "warning": "⚠️ Warning", "critical": "🚨 Critical"}


def metric_card(label, value, level, delta=None, note=None):
    with st.container(border=True):
        st.metric(label, value, delta=delta, delta_color="off")
        st.caption(ICON[level] + (f" · {note}" if note else ""))


def trend_chart(df, series, title, band=None, key=None, height=260):
    fig = go.Figure()
    for col, name in series:
        fig.add_trace(go.Scatter(x=df["time"], y=df[col], mode="lines", name=name))
    if band:  # green band = normal range
        fig.add_hrect(y0=band[0], y1=band[1], fillcolor="green", opacity=0.08, line_width=0)
    fig.update_layout(title=title, height=height, template="plotly_white",
                      margin=dict(l=10, r=10, t=40, b=10),
                      legend=dict(orientation="h", y=-0.2))
    st.plotly_chart(fig, use_container_width=True, key=key)


def show_alerts(active):
    if not active:
        st.success("All readings are within normal ranges.")
    for a in active:
        (st.error if a["severity"] == "critical" else st.warning)(
            f"**{a['type']}** – {a['message']}")


def climate_status():
    ss = st.session_state
    cols = st.columns(4)
    for col, (key, name) in zip(cols, core.DEVICE_NAMES.items()):
        on = ss.devices[key]
        col.metric(name, "🟢 ON" if on else "⚫ OFF")
    cols[3].metric("Auto Mode", "🤖 ON" if ss.auto_mode else "Manual")


def call_buttons(prefix, reading):
    """Simulated Call Nurse / Send Mobile Alert buttons."""
    ss = st.session_state
    p, room = ss.patient, ss.get("room", ss.patient["room"])
    c1, c2, _ = st.columns([1, 1, 2])
    if c1.button("🚨 Call Nurse", type="primary", key=f"{prefix}_nurse"):
        alerts.log("Nurse Call", "critical", f"Nurse called to Room {room} for {p['name']}")
        core.notify(f"✅ Nurse call sent! A nurse is on the way to Room {room}.")
    if c2.button("📱 Send Mobile Alert", key=f"{prefix}_mobile"):
        summary = f"HR {reading['heart_rate']}, SpO2 {reading['spo2']}%, Temp {reading['temperature']}°C"
        alerts.log("Mobile Alert", "warning", f"Simulated mobile alert for {p['name']} ({summary})")
        core.notify("📱 Simulated mobile alert sent to the on-call team.")
    core.show_notice()
