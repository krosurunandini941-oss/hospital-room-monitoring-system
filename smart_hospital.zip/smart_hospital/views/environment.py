import streamlit as st
import alerts, core, ui
from config import check

LIVE = True


def _set_device(name):
    st.session_state.devices[name] = st.session_state[f"tg_{name}"]


def _set_auto():
    st.session_state.auto_mode = st.session_state.w_auto


def render():
    ss = st.session_state
    th = ss.thresholds
    df = core.history_df()
    cur = df.iloc[-1]

    st.title("🌡️ Room Environment")
    c = st.columns(5)
    for col, k, fmt in zip(c, ["room_temp", "humidity", "air_quality", "co", "co2"],
                           ["{:.1f}", "{:.1f}", "{:.0f}", "{:.1f}", "{:.0f}"]):
        with col:
            t = th[k]
            ui.metric_card(t["label"], f"{fmt.format(cur[k])} {t['unit']}", check(cur[k], t)[0],
                           note=f"safe ≤ {t['high']}" if t["low"] == 0 else f"safe {t['low']}–{t['high']}")
    st.progress(min(cur.air_quality / 200, 1.0), text=f"Air quality index: {cur.air_quality:.0f} (safe ≤ {th['air_quality']['high']})")

    ui.show_alerts([a for a in alerts.evaluate(cur, th) if a["type"] == "Environment"])

    st.subheader("Trends")
    charts = [("room_temp", "Room Temperature (°C)"), ("humidity", "Humidity (%)"),
              ("air_quality", "Air Quality (AQI)"), ("co", "CO (ppm)"), ("co2", "CO2 (ppm)")]
    for i in range(0, len(charts), 2):
        cols = st.columns(2)
        for col, (k, title) in zip(cols, charts[i:i + 2]):
            with col:
                ui.trend_chart(df, [(k, title)], title, (th[k]["low"], th[k]["high"]), f"e_{k}")

    st.subheader("Climate Control")
    ss.w_auto = ss.auto_mode
    st.toggle("🤖 Auto Mode (fan/AC when too hot, humidifier when too dry)",
              key="w_auto", on_change=_set_auto)
    st.caption(f"Auto limits → turn fan/AC ON above {th['room_temp']['high']} °C, "
               f"humidifier ON below {th['humidity']['low']} % (change in sidebar).")
    cols = st.columns(3)
    for col, (name, label) in zip(cols, core.DEVICE_NAMES.items()):
        ss[f"tg_{name}"] = ss.devices[name]
        col.toggle(label, key=f"tg_{name}", disabled=ss.auto_mode,
                   on_change=_set_device, args=(name,))
    if ss.auto_mode:
        st.info("Manual switches are locked while Auto Mode is ON.")
    ui.climate_status()
