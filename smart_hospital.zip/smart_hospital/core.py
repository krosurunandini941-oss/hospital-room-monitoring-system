"""Session state, the 'tick' that produces a new reading, and auto climate control."""
from copy import deepcopy
from datetime import datetime, timedelta
import pandas as pd
import streamlit as st
import alerts
import database as db
from config import THRESHOLDS
from simulator import SensorSimulator

MAX_POINTS = 150
DEVICE_NAMES = {"fan": "Fan", "ac": "Air Conditioner", "humidifier": "Humidifier"}


def init_state():
    ss = st.session_state
    if "ready" in ss:
        return
    db.init_db()
    ss.thresholds = deepcopy(THRESHOLDS)
    ss.sim = SensorSimulator()
    ss.devices = {"fan": False, "ac": False, "humidifier": False}
    ss.auto_mode = True
    ss.scenario = "Normal"
    ss.alert_last = {}
    ss.notice = None  # (text, kind, time) confirmation message
    ss.history = []
    now = datetime.now()
    for i in range(40, 0, -1):  # pre-fill so charts aren't empty
        r = ss.sim.step(ss.devices)
        r["time"] = now - timedelta(seconds=2 * i)
        ss.history.append(r)
    ss.ready = True


def history_df():
    return pd.DataFrame(st.session_state.history)


def apply_auto_mode(reading):
    ss = st.session_state
    th, d = ss.thresholds, ss.devices
    t_limit, h_limit = th["room_temp"]["high"], th["humidity"]["low"]
    new = dict(d)
    if reading["room_temp"] > t_limit:
        new["fan"] = new["ac"] = True
    elif reading["room_temp"] < t_limit - 1.0:      # 1 degree hysteresis
        new["fan"] = new["ac"] = False
    if reading["humidity"] < h_limit:
        new["humidifier"] = True
    elif reading["humidity"] > h_limit + 10:
        new["humidifier"] = False
    for name, state in new.items():
        if state != d[name]:
            d[name] = state
            alerts.log("Climate", "info",
                       f"Auto mode turned {DEVICE_NAMES[name]} {'ON' if state else 'OFF'}")


def tick():
    """Generate one new sensor reading, update devices and alerts."""
    ss = st.session_state
    reading = ss.sim.step(ss.devices)
    reading["time"] = datetime.now()
    ss.history.append(reading)
    ss.history = ss.history[-MAX_POINTS:]
    if ss.auto_mode:
        apply_auto_mode(reading)
    alerts.record_active(alerts.evaluate(reading, ss.thresholds))


def notify(text, kind="success"):
    st.session_state.notice = (text, kind, datetime.now())
    st.toast(text)


def show_notice(seconds=20):
    n = st.session_state.notice
    if n and (datetime.now() - n[2]).total_seconds() < seconds:
        getattr(st, n[1])(n[0])
