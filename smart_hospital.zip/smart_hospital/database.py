"""Tiny SQLite layer (patients + alert history)."""
import sqlite3
from contextlib import closing
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "hospital.db"

SEED = [
    ("P001", "Ravi Kumar", 54, "101", "Dr. Anita Sharma", "2026-09-27"),
    ("P002", "Lakshmi Devi", 67, "102", "Dr. Suresh Rao", "2026-09-29"),
    ("P003", "Arjun Reddy", 35, "103", "Dr. Meera Nair", "2026-09-30"),
]


def _conn():
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with closing(_conn()) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS patients (
            patient_id TEXT PRIMARY KEY, name TEXT, age INTEGER,
            room TEXT, doctor TEXT, admission_date TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, patient_id TEXT,
            alert_type TEXT, severity TEXT, message TEXT)""")
        if c.execute("SELECT COUNT(*) FROM patients").fetchone()[0] == 0:
            c.executemany("INSERT INTO patients VALUES (?,?,?,?,?,?)", SEED)
        c.commit()


def get_patients():
    with closing(_conn()) as c:
        return [dict(r) for r in c.execute("SELECT * FROM patients ORDER BY patient_id")]


def save_patient(pid, name, age, room, doctor, admission_date):
    with closing(_conn()) as c:
        c.execute("INSERT OR REPLACE INTO patients VALUES (?,?,?,?,?,?)",
                  (pid, name, age, room, doctor, admission_date))
        c.commit()


def add_alert(timestamp, patient_id, alert_type, severity, message):
    with closing(_conn()) as c:
        c.execute("INSERT INTO alerts (timestamp, patient_id, alert_type, severity, message)"
                  " VALUES (?,?,?,?,?)", (timestamp, patient_id, alert_type, severity, message))
        c.commit()


def get_alerts(limit=500):
    with closing(_conn()) as c:
        return [dict(r) for r in c.execute(
            "SELECT timestamp, patient_id, alert_type, severity, message "
            "FROM alerts ORDER BY id DESC LIMIT ?", (limit,))]


def clear_alerts():
    with closing(_conn()) as c:
        c.execute("DELETE FROM alerts")
        c.commit()
