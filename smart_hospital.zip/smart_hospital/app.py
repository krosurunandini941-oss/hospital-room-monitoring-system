"""Smart Hospital Room Monitoring System  –  run with:  streamlit run app.py"""
import streamlit as st
import core
import database as db
from config import THRESHOLDS
from views import dashboard, ehr, environment, alerts_page, settings_page

st.set_page_config(page_title="Smart Hospital Room Monitoring", page_icon="🏥", layout="wide")
core.init_state()
ss = st.session_state

PAGES = {
    "🏠 Dashboard": dashboard,
    "🧑‍⚕️ Patient / EHR": ehr,
    "🌡️ Environment": environment,
    "🔔 Alerts": alerts_page,
    "⚙️ Settings": settings_page,
}

# ---------------- Sidebar ----------------
st.sidebar.title("🏥 Room Monitor")
page = st.sidebar.radio("Navigation", list(PAGES), label_visibility="collapsed")
st.sidebar.divider()

patients = {f"{p['patient_id']} – {p['name']}": p for p in db.get_patients()}
choice = st.sidebar.selectbox("Patient", list(patients))
ss.patient = patients[choice]
ss.room = st.sidebar.text_input("Room number", value=ss.patient["room"],
                                key=f"room_{ss.patient['patient_id']}")

st.sidebar.toggle("Auto-refresh", value=True, key="auto_refresh")
st.sidebar.slider("Refresh every (seconds)", 1, 10, 2, key="refresh_s")
if not ss.auto_refresh and st.sidebar.button("▶️ Next reading"):
    core.tick()

with st.sidebar.expander("Threshold settings", expanded=True):
    st.number_input("Max room temperature (°C)", 15.0, 40.0,
                    float(THRESHOLDS["room_temp"]["high"]), 0.5, key="lim_temp")
    st.number_input("Min humidity (%)", 10.0, 80.0,
                    float(THRESHOLDS["humidity"]["low"]), 1.0, key="lim_hum")
    st.caption("Used for warnings and Auto Mode. More on the Settings page.")
ss.thresholds["room_temp"]["high"] = ss.lim_temp
ss.thresholds["humidity"]["low"] = ss.lim_hum

# ---------------- Page ----------------
view = PAGES[page]
if getattr(view, "LIVE", False):
    @st.fragment(run_every=ss.refresh_s if ss.auto_refresh else None)
    def live_view():
        if ss.auto_refresh:
            core.tick()
        view.render()
    live_view()
else:
    view.render()
