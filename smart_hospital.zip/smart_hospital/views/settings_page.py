from copy import deepcopy
import streamlit as st
from config import THRESHOLDS
from simulator import SCENARIOS

LIVE = False
SIDEBAR_ONLY = {("room_temp", "high"), ("humidity", "low")}  # edited in the sidebar


def _reset():
    ss = st.session_state
    ss.thresholds = deepcopy(THRESHOLDS)
    ss.lim_temp = float(THRESHOLDS["room_temp"]["high"])
    ss.lim_hum = float(THRESHOLDS["humidity"]["low"])


def render():
    ss = st.session_state
    st.title("⚙️ Settings")

    st.subheader("Sensor simulation")
    names = list(SCENARIOS)
    choice = st.selectbox("Scenario (for demos – makes readings drift toward abnormal values)",
                          names, index=names.index(ss.scenario))
    if choice != ss.scenario:
        ss.scenario = choice
        ss.sim.set_scenario(choice)
        st.toast(f"Scenario: {choice}")

    st.subheader("Thresholds")
    st.caption("Warning outside normal range (low–high). Critical beyond the critical limits.")
    with st.form("th_form"):
        new = {}
        hdr = st.columns([2, 1, 1, 1, 1])
        for h, t in zip(hdr, ["Parameter", "Normal low", "Normal high", "Critical low", "Critical high"]):
            h.markdown(f"**{t}**")
        for k, t in ss.thresholds.items():
            step = 0.1 if t["unit"] == "°C" else 1.0
            row = st.columns([2, 1, 1, 1, 1])
            row[0].write(f"{t['label']} ({t['unit']})")
            vals = {}
            for col, field in zip(row[1:], ["low", "high", "crit_low", "crit_high"]):
                if (k, field) in SIDEBAR_ONLY:
                    col.caption("set in sidebar")
                    vals[field] = t[field]
                else:
                    vals[field] = col.number_input(f"{k}_{field}", value=float(t[field]), step=step,
                                                   label_visibility="collapsed", key=f"th_{k}_{field}")
            new[k] = vals
        if st.form_submit_button("💾 Save thresholds", type="primary"):
            for k, vals in new.items():
                ss.thresholds[k].update(vals)
            st.success("Thresholds saved.")
    st.button("↩️ Reset to defaults", on_click=_reset)
