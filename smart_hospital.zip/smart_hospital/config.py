"""Default thresholds. low/high = normal range (warning outside it),
crit_low/crit_high = critical limits. Editable at runtime on the Settings page."""

ORDER = {"normal": 0, "warning": 1, "critical": 2}


def _t(label, unit, low, high, crit_low, crit_high, kind):
    return dict(label=label, unit=unit, low=low, high=high,
                crit_low=crit_low, crit_high=crit_high, kind=kind)


THRESHOLDS = {
    # --- patient vitals ---
    "heart_rate":  _t("Heart Rate", "BPM", 60, 100, 50, 120, "vital"),
    "systolic":    _t("Systolic BP", "mmHg", 90, 120, 80, 160, "vital"),
    "diastolic":   _t("Diastolic BP", "mmHg", 60, 80, 50, 100, "vital"),
    "spo2":        _t("SpO2", "%", 95, 100, 90, 100, "vital"),
    "resp_rate":   _t("Respiratory Rate", "breaths/min", 12, 20, 8, 25, "vital"),
    "temperature": _t("Body Temperature", "°C", 36.5, 37.5, 35.0, 39.0, "vital"),
    # --- room environment ---
    "room_temp":   _t("Room Temperature", "°C", 20, 28, 16, 32, "env"),
    "humidity":    _t("Humidity", "%", 40, 60, 30, 75, "env"),
    "air_quality": _t("Air Quality (AQI)", "AQI", 0, 100, 0, 150, "env"),
    "co":          _t("CO", "ppm", 0, 9, 0, 35, "env"),
    "co2":         _t("CO2", "ppm", 0, 1000, 0, 2000, "env"),
}


def check(value, th):
    """Return (level, direction): level is normal/warning/critical."""
    if value < th["crit_low"]:
        return "critical", "too low"
    if value > th["crit_high"]:
        return "critical", "too high"
    if value < th["low"]:
        return "warning", "too low"
    if value > th["high"]:
        return "warning", "too high"
    return "normal", ""


def worst(*levels):
    return max(levels, key=lambda l: ORDER[l])
