import streamlit as st
import alerts, core, ui
from config import check, worst

LIVE = True


def render():
    ss = st.session_state
    th, p = ss.thresholds, ss.patient
    df = core.history_df()
    cur, prev = df.iloc[-1], df.iloc[-2]

    st.title("🏥 Smart Hospital Room Monitoring")
    c = st.columns(4)
    c[0].metric("Patient", p["name"])
    c[1].metric("Age", p["age"])
    c[2].metric("Room", ss.get("room", p["room"]))
    c[3].metric("Doctor", p["doctor"])

    lv = {k: check(cur[k], t)[0] for k, t in th.items()}
    d = lambda k, f="{:+.0f}": f.format(cur[k] - prev[k])

    st.subheader("Vital Signs")
    c = st.columns(5)
    with c[0]:
        ui.metric_card("❤️ Heart Rate", f"{cur.heart_rate:.0f} BPM", lv["heart_rate"], d("heart_rate"))
    with c[1]:
        ui.metric_card("🩸 Blood Pressure", f"{cur.systolic:.0f}/{cur.diastolic:.0f}",
                       worst(lv["systolic"], lv["diastolic"]), d("systolic"), "mmHg")
    with c[2]:
        ui.metric_card("🫁 SpO2", f"{cur.spo2:.1f} %", lv["spo2"], d("spo2", "{:+.1f}"))
    with c[3]:
        ui.metric_card("🌬️ Resp. Rate", f"{cur.resp_rate:.1f} /min", lv["resp_rate"], d("resp_rate", "{:+.1f}"))
    with c[4]:
        ui.metric_card("🌡️ Body Temp", f"{cur.temperature:.2f} °C", lv["temperature"], d("temperature", "{:+.2f}"))
    st.progress(min(cur.spo2 / 100, 1.0), text=f"Oxygen saturation: {cur.spo2:.1f}%")

    tab1, tab2 = st.tabs(["📈 Vital trends", "🌿 Environment trends"])
    with tab1:
        a, b = st.columns(2)
        with a:
            ui.trend_chart(df, [("heart_rate", "Heart rate")], "Heart Rate (BPM)",
                           (th["heart_rate"]["low"], th["heart_rate"]["high"]), "d_hr")
        with b:
            ui.trend_chart(df, [("systolic", "Systolic"), ("diastolic", "Diastolic")],
                           "Blood Pressure (mmHg)", key="d_bp")
        a, b = st.columns(2)
        with a:
            ui.trend_chart(df, [("spo2", "SpO2")], "SpO2 (%)",
                           (th["spo2"]["low"], th["spo2"]["high"]), "d_spo2")
        with b:
            ui.trend_chart(df, [("resp_rate", "Resp. rate")], "Respiratory Rate (breaths/min)",
                           (th["resp_rate"]["low"], th["resp_rate"]["high"]), "d_rr")
        ui.trend_chart(df, [("temperature", "Temperature")], "Body Temperature (°C)",
                       (th["temperature"]["low"], th["temperature"]["high"]), "d_temp")
    with tab2:
        a, b, c = st.columns(3)
        with a:
            ui.trend_chart(df, [("room_temp", "Temp")], "Room Temperature (°C)",
                           (th["room_temp"]["low"], th["room_temp"]["high"]), "d_rt")
        with b:
            ui.trend_chart(df, [("humidity", "Humidity")], "Humidity (%)",
                           (th["humidity"]["low"], th["humidity"]["high"]), "d_hum")
        with c:
            ui.trend_chart(df, [("co2", "CO2")], "CO2 (ppm)",
                           (th["co2"]["low"], th["co2"]["high"]), "d_co2")

    st.subheader("Environment")
    c = st.columns(5)
    for col, k, fmt in zip(c, ["room_temp", "humidity", "air_quality", "co", "co2"],
                           ["{:.1f}", "{:.1f}", "{:.0f}", "{:.1f}", "{:.0f}"]):
        with col:
            t = th[k]
            ui.metric_card(t["label"], f"{fmt.format(cur[k])} {t['unit']}", lv[k],
                           note=f"safe ≤ {t['high']}" if t["low"] == 0 else f"safe {t['low']}–{t['high']}")

    st.subheader("Climate Control")
    ui.climate_status()

    st.subheader("Alerts")
    active = alerts.evaluate(cur, th)
    ui.show_alerts(active)
    ui.call_buttons("dash", cur)
